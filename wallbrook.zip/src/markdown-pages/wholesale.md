---
title: For wholesale clients
subtitle: We offer specific opportunities available through our network only to
  Wholesale clients. We do this on a non-advised, introduction only basis to
  contacts with sufficient investment knowledge and experience who have
  previously expressed an interest.
thumbnail: ../src/images/wholesale.png
title2: We offer an open-architecture service that meets the needs of both
  Retail and Wholesale private clients and their families
subtitle2: We are typically asked to assist with introductions in the following areas
contacttitle: To be kept abreast of these opportunities, please contact us
email: info@walbrook.com.au
contact: +61 3 9013 6262
listitems:
  - title: |
      Seed funding
  - title: |
      Pre-IPO equity, on a primary or secondary basis
  - title: |
      Private equity, on a fund or co-investment basis, including secondaries
  - title: Real estate, on a fund, direct or co-investment basis
page: true
list: d
---
