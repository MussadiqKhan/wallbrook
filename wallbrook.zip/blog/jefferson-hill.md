---
blogtitle: Jefferson Hill
path: jefferson-hill
date: 2020-08-25T14:43:10.979Z
author: Mike
blogpage: true
thumbnail: ../src/images/image-3.png
---

the Subscriber and any User who enjoys any of the benefits of a Service Plan in relation to which he is not the Subscriber shall, as respects the given Service Plan, have an Agreement with the Supplier under subsection 2.1(b). That Agreement: (α) between the Supplier and the Subscriber shall be effective upon the Supplier's acceptance of the order for the Service Plan, whether explicitly or impliedly, with implied acceptance being deemed to have been given by making the relevant Features available; (β) between the Supplier and a User other than the Subscriber shall be effective upon any of the Service Plan's benefits becoming available to the User; and, in either case (γ) shall terminate upon (i) a new Agreement being made between the Supplier and a Subscriber under subsection 2.1(b) in relation to the Workspace concerned, i.e., where the Service Plan attaching to the Workspace is replaced by another, (ii) the expiry of the Service Plan, (iii) the User ceasing to be a member of the Workspace (in which event the Agreement in question will only terminate in respect of the particular User), or (iv) the Workspace being closed;

![](../src/images/image-3.png)
