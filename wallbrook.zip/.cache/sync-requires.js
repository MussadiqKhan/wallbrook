const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---cache-dev-404-page-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\.cache\\dev-404-page.js"))),
  "component---src-pages-404-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\404.js"))),
  "component---src-pages-about-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\about.js"))),
  "component---src-pages-blog-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\blog.js"))),
  "component---src-pages-continuing-professional-development-policy-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\continuing-professional-development-policy.js"))),
  "component---src-pages-education-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\education.js"))),
  "component---src-pages-financial-services-guide-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\financial-services-guide.js"))),
  "component---src-pages-how-we-do-it-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\how-we-do-it.js"))),
  "component---src-pages-index-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\index.js"))),
  "component---src-pages-privacy-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\privacy.js"))),
  "component---src-pages-thank-you-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\thank-you.js"))),
  "component---src-pages-what-we-do-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\what-we-do.js"))),
  "component---src-pages-wholesale-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\pages\\wholesale.js"))),
  "component---src-templates-blog-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\templates\\blog.js"))),
  "component---src-templates-education-js": hot(preferDefault(require("C:\\Users\\musad\\OneDrive\\Desktop\\Fiverr Projects\\wallbrook\\src\\templates\\education.js")))
}

